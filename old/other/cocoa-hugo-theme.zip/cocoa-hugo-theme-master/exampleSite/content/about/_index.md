+++
date = "2015-08-22T06:42:21-07:00"
draft = false
title = "About"

+++

Along with [Ford Prefect](https://en.wikipedia.org/wiki/Ford_Prefect_\(character\)), Dent barely escapes the Earth's destruction as it is demolished to make way for a *hyperspace bypass*. Arthur spends the next several years, still wearing his dressing gown, helplessly launched from crisis to crisis while trying to straighten out his lifestyle. 

> He rather enjoys tea, but seems to have trouble obtaining it in the far reaches of the galaxy. 

In time, he learns how to fly and carves a niche for himself as a sandwich-maker.

<img src="//placehold.it/300x300" class="profile">

<br />

[About this site](colophon/)
