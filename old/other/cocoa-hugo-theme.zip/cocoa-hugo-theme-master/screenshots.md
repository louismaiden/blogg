## Screenshots

<img src="https://raw.githubusercontent.com/nishanths/cocoa-hugo-theme/master/images/tn.png" width="800">

<img src="https://i.imgur.com/jdstF9j.png" width="800">

### Smaller screen width

<img src="https://i.imgur.com/5jI8kEU.png" width="400">

### Switch between languages

<img src="https://raw.githubusercontent.com/nishanths/cocoa-hugo-theme/master/images/scr.de-fullpage.png" title="german screenshot" width="300"> <img src="https://raw.githubusercontent.com/nishanths/cocoa-hugo-theme/master/images/scr.en-fullpage.png" title="english screenshot" width="300">
